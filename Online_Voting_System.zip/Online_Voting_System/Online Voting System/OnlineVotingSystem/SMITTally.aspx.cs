﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class SMITTally : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetVotes_SMIT_PRESIDENT();
            GetVotes_SMIT_SECRETARY();
            GetVotes_SMIT_PUBLIC();
            GetVotes_SMIT_114();
            GetVotes_SMIT_115();
        }
    }


    void GetVotes_SMIT_PRESIDENT()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = @"SELECT c.canName,
                (SELECT COUNT(VoteID) FROM votes v
                WHERE v.canID = c.canID) AS TotalVotes
                 FROM candidates c
                WHERE c.positionID = 16";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    lvResults_SMIT_PRESIDENT.DataSource = dr;
                    lvResults_SMIT_PRESIDENT.DataBind();
                }
            }
        }
    }

    void GetVotes_SMIT_SECRETARY()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = @"SELECT c.canName,
                (SELECT COUNT(VoteID) FROM votes v
                WHERE v.canID = c.canID) AS TotalVotes
                 FROM candidates c
                WHERE c.positionID = 17";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    lvResults_SMIT_SECRETARY.DataSource = dr;
                    lvResults_SMIT_SECRETARY.DataBind();
                }
            }
        }
    }

    void GetVotes_SMIT_PUBLIC()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = @"SELECT c.canName,
                (SELECT COUNT(VoteID) FROM votes v
                WHERE v.canID = c.canID) AS TotalVotes
                 FROM candidates c
                WHERE c.positionID = 18";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    lvResults_SMIT_PUBLIC.DataSource = dr;
                    lvResults_SMIT_PUBLIC.DataBind();
                }
            }
        }
    }

    void GetVotes_SMIT_114()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = @"SELECT c.canName,
                (SELECT COUNT(VoteID) FROM votes v
                WHERE v.canID = c.canID) AS TotalVotes
                 FROM candidates c
                WHERE c.positionID = 19";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    lvResults_SMIT_114.DataSource = dr;
                    lvResults_SMIT_114.DataBind();
                }
            }
        }
    }

    void GetVotes_SMIT_115()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = @"SELECT c.canName,
                (SELECT COUNT(VoteID) FROM votes v
                WHERE v.canID = c.canID) AS TotalVotes
                 FROM candidates c
                WHERE c.positionID = 20";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    lvResults_SMIT_115.DataSource = dr;
                    lvResults_SMIT_115.DataBind();
                }
            }
        }
    }
    protected void btnSchools_Click(object sender, EventArgs e)
    {
        Response.Redirect("Schools.aspx");
    }

}
