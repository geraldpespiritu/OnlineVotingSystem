﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class SDEASTally : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetVotes_SDEAS_PRESIDENT();
            GetVotes_SDEAS_SECRETARY();
            GetVotes_SDEAS_PUBLIC();
            GetVotes_SDEAS_114();
            GetVotes_SDEAS_115();
        }
    }


    void GetVotes_SDEAS_PRESIDENT()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = @"SELECT c.canName,
                (SELECT COUNT(VoteID) FROM votes v
                WHERE v.canID = c.canID) AS TotalVotes
                 FROM candidates c
                WHERE c.positionID = 26";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    lvResults_SDEAS_PRESIDENT.DataSource = dr;
                    lvResults_SDEAS_PRESIDENT.DataBind();
                }
            }
        }
    }

    void GetVotes_SDEAS_SECRETARY()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = @"SELECT c.canName,
                (SELECT COUNT(VoteID) FROM votes v
                WHERE v.canID = c.canID) AS TotalVotes
                 FROM candidates c
                WHERE c.positionID = 27";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    lvResults_SDEAS_SECRETARY.DataSource = dr;
                    lvResults_SDEAS_SECRETARY.DataBind();
                }
            }
        }
    }

    void GetVotes_SDEAS_PUBLIC()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = @"SELECT c.canName,
                (SELECT COUNT(VoteID) FROM votes v
                WHERE v.canID = c.canID) AS TotalVotes
                 FROM candidates c
                WHERE c.positionID = 28";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    lvResults_SDEAS_PUBLIC.DataSource = dr;
                    lvResults_SDEAS_PUBLIC.DataBind();
                }
            }
        }
    }

    void GetVotes_SDEAS_114()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = @"SELECT c.canName,
                (SELECT COUNT(VoteID) FROM votes v
                WHERE v.canID = c.canID) AS TotalVotes
                 FROM candidates c
                WHERE c.positionID = 29";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    lvResults_SDEAS_114.DataSource = dr;
                    lvResults_SDEAS_114.DataBind();
                }
            }
        }
    }

    void GetVotes_SDEAS_115()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = @"SELECT c.canName,
                (SELECT COUNT(VoteID) FROM votes v
                WHERE v.canID = c.canID) AS TotalVotes
                 FROM candidates c
                WHERE c.positionID = 30";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    lvResults_SDEAS_115.DataSource = dr;
                    lvResults_SDEAS_115.DataBind();
                }
            }
        }
    }



    protected void btnSchools_Click(object sender, EventArgs e)
    {
        Response.Redirect("Schools.aspx");
    }
}
