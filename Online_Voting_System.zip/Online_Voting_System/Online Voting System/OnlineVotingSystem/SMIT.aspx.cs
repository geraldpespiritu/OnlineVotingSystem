﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class SMIT : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetSMIT();
            GetSMIT2();
            GetSMIT3();
            GetSMIT4();
            GetSMIT5();

            GetCSG();
            GetCSG2();
            GetCSG3();
            GetCSG4();
            GetCSG5();

        }
    }

    void GetSMIT()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=16";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlSMIT.DataSource = data;
                    ddlSMIT.DataTextField = "canName";
                    ddlSMIT.DataValueField = "canID";
                    ddlSMIT.DataBind();

                    ddlSMIT.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }

    void GetSMIT2()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=17";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlSMIT2.DataSource = data;
                    ddlSMIT2.DataTextField = "canName";
                    ddlSMIT2.DataValueField = "canID";
                    ddlSMIT2.DataBind();

                    ddlSMIT2.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }

    void GetSMIT3()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=18";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlSMIT3.DataSource = data;
                    ddlSMIT3.DataTextField = "canName";
                    ddlSMIT3.DataValueField = "canID";
                    ddlSMIT3.DataBind();

                    ddlSMIT3.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }
    void GetSMIT4()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=19";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlSMIT4.DataSource = data;
                    ddlSMIT4.DataTextField = "canName";
                    ddlSMIT4.DataValueField = "canID";
                    ddlSMIT4.DataBind();
               
                    ddlSMIT4.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }
    void GetSMIT5()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=20";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlSMIT5.DataSource = data;
                    ddlSMIT5.DataTextField = "canName";
                    ddlSMIT5.DataValueField = "canID";
                    ddlSMIT5.DataBind();

                    ddlSMIT5.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }


    protected void ddlSMIT_SelectedIndexChanged(object sender, EventArgs e)
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = @"INSERT INTO votes VALUES(@canID, @studentID, @DateAdded)";

            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                cmd.Parameters.AddWithValue("@canID", ddlSMIT.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@studentID", ddlSMIT.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@DateAdded", DateTime.Now);
                cmd.ExecuteNonQuery();
            }
        }
    }


    void GetCSG()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=1";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlCSG.DataSource = data;
                    ddlCSG.DataTextField = "canName";
                    ddlCSG.DataValueField = "canID";
                    ddlCSG.DataBind();

                    ddlCSG.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }

    void GetCSG2()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=2";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlCSG2.DataSource = data;
                    ddlCSG2.DataTextField = "canName";
                    ddlCSG2.DataValueField = "canID";
                    ddlCSG2.DataBind();

                    ddlCSG2.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }

    void GetCSG3()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=3";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlCSG3.DataSource = data;
                    ddlCSG3.DataTextField = "canName";
                    ddlCSG3.DataValueField = "canID";
                    ddlCSG3.DataBind();

                    ddlCSG3.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }

    void GetCSG4()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=4";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlCSG4.DataSource = data;
                    ddlCSG4.DataTextField = "canName";
                    ddlCSG4.DataValueField = "canID";
                    ddlCSG4.DataBind();

                    ddlCSG4.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }
    void GetCSG5()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=5";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlCSG5.DataSource = data;
                    ddlCSG5.DataTextField = "canName";
                    ddlCSG5.DataValueField = "canID";
                    ddlCSG5.DataBind();

                    ddlCSG5.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }

    protected void ddlCSG_SelectedIndexChanged(object sender, EventArgs e)
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = @"INSERT INTO votes VALUES(@canID, @studentID, @DateAdded)";

            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                cmd.Parameters.AddWithValue("@canID", ddlCSG.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@studentID", ddlCSG.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@DateAdded", DateTime.Now);
                cmd.ExecuteNonQuery();
            }
        }
    }




    protected void btnFinish_Click(object sender, EventArgs e)
    {
        Response.Redirect("Finish.aspx");
    }
    
}
