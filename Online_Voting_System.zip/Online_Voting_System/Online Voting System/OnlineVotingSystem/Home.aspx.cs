﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;

public partial class Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["schoolName"].ToString() == "SMIT")
        {
            Response.Redirect("SMIT.aspx");
        }
        else if (Session["SchoolName"].ToString() == "SDA")
        {
            Response.Redirect("SDA.aspx");
        }
        else if (Session["schoolName"].ToString() == "SHRIM")
        {
            Response.Redirect("SHRIM.aspx");
        }
        else if (Session["schoolName"].ToString() == "SMS")
        {
            Response.Redirect("SMS.aspx");
        }
        else if (Session["schoolName"].ToString() == "SDEAS")
        {
            Response.Redirect("SDEAS.aspx");
        }
    }

    void GetData()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = @"SELECT studentID, schoolName FROM students
                            WHERE studentIDNumber = @studentIDNumber AND studentPW = @studentPW";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                cmd.Parameters.AddWithValue("@studentID", Session["studentID"].ToString());

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        ltID.Text = dr["studentID"].ToString();
                        ltIDNumber.Text = dr["studentIDNumber"].ToString();
                        ltSchool.Text = dr["schoolName"].ToString();
                    }
                }

            }

        }
    }
}