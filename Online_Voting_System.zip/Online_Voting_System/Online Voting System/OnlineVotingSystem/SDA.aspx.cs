﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class SDA : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetSDA();
            GetSDA2();
            GetSDA3();
            GetSDA4();
            GetSDA5();

            GetCSG();
            GetCSG2();
            GetCSG3();
            GetCSG4();
            GetCSG5();
        }
    }

    void GetSDA()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=6";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlSDA.DataSource = data;
                    ddlSDA.DataTextField = "canName";
                    ddlSDA.DataValueField = "canID";
                    ddlSDA.DataBind();

                    ddlSDA.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }

    void GetSDA2()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=7";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlSDA2.DataSource = data;
                    ddlSDA2.DataTextField = "canName";
                    ddlSDA2.DataValueField = "canID";
                    ddlSDA2.DataBind();

                    ddlSDA2.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }


    void GetSDA3()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=8";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlSDA3.DataSource = data;
                    ddlSDA3.DataTextField = "canName";
                    ddlSDA3.DataValueField = "canID";
                    ddlSDA3.DataBind();

                    ddlSDA3.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }


    void GetSDA4()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=9";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlSDA4.DataSource = data;
                    ddlSDA4.DataTextField = "canName";
                    ddlSDA4.DataValueField = "canID";
                    ddlSDA4.DataBind();

                    ddlSDA4.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }


    void GetSDA5()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=10";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlSDA5.DataSource = data;
                    ddlSDA5.DataTextField = "canName";
                    ddlSDA5.DataValueField = "canID";
                    ddlSDA5.DataBind();

                    ddlSDA5.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }


    protected void ddlSDA_SelectedIndexChanged(object sender, EventArgs e)
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = @"INSERT INTO votes VALUES(@canID, @studentID, @DateAdded)";

            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                cmd.Parameters.AddWithValue("@canID", ddlSDA.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@studentID", ddlSDA.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@DateAdded", DateTime.Now);
                cmd.ExecuteNonQuery();
            }
        }
    }


    void GetCSG()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=1";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlCSG.DataSource = data;
                    ddlCSG.DataTextField = "canName";
                    ddlCSG.DataValueField = "canID";
                    ddlCSG.DataBind();

                    ddlCSG.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }

    void GetCSG2()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=2";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlCSG2.DataSource = data;
                    ddlCSG2.DataTextField = "canName";
                    ddlCSG2.DataValueField = "canID";
                    ddlCSG2.DataBind();

                    ddlCSG2.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }

    void GetCSG3()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=3";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlCSG3.DataSource = data;
                    ddlCSG3.DataTextField = "canName";
                    ddlCSG3.DataValueField = "canID";
                    ddlCSG3.DataBind();

                    ddlCSG3.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }

    void GetCSG4()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=4";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlCSG4.DataSource = data;
                    ddlCSG4.DataTextField = "canName";
                    ddlCSG4.DataValueField = "canID";
                    ddlCSG4.DataBind();

                    ddlCSG4.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }
    void GetCSG5()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=5";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlCSG5.DataSource = data;
                    ddlCSG5.DataTextField = "canName";
                    ddlCSG5.DataValueField = "canID";
                    ddlCSG5.DataBind();

                    ddlCSG5.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }
    protected void ddlCSG_SelectedIndexChanged(object sender, EventArgs e)
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = @"INSERT INTO votes VALUES(@canID, @studentID, @DateAdded)";

            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                cmd.Parameters.AddWithValue("@canID", ddlCSG.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@studentID", ddlCSG.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@DateAdded", DateTime.Now);
                cmd.ExecuteNonQuery();
            }
        }
    }

    protected void btnFinish_Click(object sender, EventArgs e)
    {
        Response.Redirect("Finish.aspx");
    }
}

