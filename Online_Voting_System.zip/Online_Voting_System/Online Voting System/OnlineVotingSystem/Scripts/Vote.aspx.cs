﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Vote : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetPositions();
            GetCandidates(ddlPositions.SelectedValue);
        }
    }
    void GetPositions()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = "SELECT positionID, positionName FROM positions";

            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlPositions.DataSource = data;
                    ddlPositions.DataTextField = "positionName";
                    ddlPositions.DataValueField = "positionID";
                    ddlPositions.DataBind();

                    ddlPositions.Items.Insert(0, new ListItem("Select a position...", ""));
                }
            }
        }
    }

    void GetCandidates(string positionID)
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = "SELECT canID, canName FROM candidates WHERE positionID=@positionID ORDER BY canName ASC";

            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                cmd.Parameters.AddWithValue("@positionID", positionID);
                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    rblCandidates.DataSource = data;
                    rblCandidates.DataTextField = "canName";
                    rblCandidates.DataValueField = "canID";
                    rblCandidates.DataBind();
                }
            }
        }
    }
    protected void ddlPositions_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlPositions.SelectedIndex != 0)
        {
            GetCandidates(ddlPositions.SelectedValue);
        }
    }
}