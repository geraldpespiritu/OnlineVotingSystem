﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class SDEAS : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetSDEAS();
            GetSDEAS2();
            GetSDEAS3();
            GetSDEAS4();
            GetSDEAS5();

            GetCSG();
            GetCSG2();
            GetCSG3();
            GetCSG4();
            GetCSG5();
        }
    }

    void GetSDEAS()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=26";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlSDEAS.DataSource = data;
                    ddlSDEAS.DataTextField = "canName";
                    ddlSDEAS.DataValueField = "canID";
                    ddlSDEAS.DataBind();

                    ddlSDEAS.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }

    void GetSDEAS2()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=27";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlSDEAS2.DataSource = data;
                    ddlSDEAS2.DataTextField = "canName";
                    ddlSDEAS2.DataValueField = "canID";
                    ddlSDEAS2.DataBind();

                    ddlSDEAS2.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }

    void GetSDEAS3()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=28";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlSDEAS3.DataSource = data;
                    ddlSDEAS3.DataTextField = "canName";
                    ddlSDEAS3.DataValueField = "canID";
                    ddlSDEAS3.DataBind();

                    ddlSDEAS3.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }

    void GetSDEAS4()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=29";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlSDEAS4.DataSource = data;
                    ddlSDEAS4.DataTextField = "canName";
                    ddlSDEAS4.DataValueField = "canID";
                    ddlSDEAS4.DataBind();

                    ddlSDEAS4.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }

    void GetSDEAS5()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=30";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlSDEAS5.DataSource = data;
                    ddlSDEAS5.DataTextField = "canName";
                    ddlSDEAS5.DataValueField = "canID";
                    ddlSDEAS5.DataBind();

                    ddlSDEAS5.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }

    protected void ddlSDEAS_SelectedIndexChanged(object sender, EventArgs e)
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = @"INSERT INTO votes VALUES(@canID, @studentID, @DateAdded)";

            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                cmd.Parameters.AddWithValue("@canID", ddlSDEAS.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@studentID", ddlSDEAS.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@DateAdded", DateTime.Now);
                cmd.ExecuteNonQuery();
            }
        }
    }


    void GetCSG()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=1";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlCSG.DataSource = data;
                    ddlCSG.DataTextField = "canName";
                    ddlCSG.DataValueField = "canID";
                    ddlCSG.DataBind();

                    ddlCSG.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }

    void GetCSG2()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=2";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlCSG2.DataSource = data;
                    ddlCSG2.DataTextField = "canName";
                    ddlCSG2.DataValueField = "canID";
                    ddlCSG2.DataBind();

                    ddlCSG2.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }

    void GetCSG3()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=3";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlCSG3.DataSource = data;
                    ddlCSG3.DataTextField = "canName";
                    ddlCSG3.DataValueField = "canID";
                    ddlCSG3.DataBind();

                    ddlCSG3.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }

    void GetCSG4()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=4";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlCSG4.DataSource = data;
                    ddlCSG4.DataTextField = "canName";
                    ddlCSG4.DataValueField = "canID";
                    ddlCSG4.DataBind();

                    ddlCSG4.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }
    void GetCSG5()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=5";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlCSG5.DataSource = data;
                    ddlCSG5.DataTextField = "canName";
                    ddlCSG5.DataValueField = "canID";
                    ddlCSG5.DataBind();

                    ddlCSG5.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }
    protected void ddlCSG_SelectedIndexChanged(object sender, EventArgs e)
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = @"INSERT INTO votes VALUES(@canID, @studentID, @DateAdded)";

            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                cmd.Parameters.AddWithValue("@canID", ddlCSG.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@studentID", ddlCSG.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@DateAdded", DateTime.Now);
                cmd.ExecuteNonQuery();
            }
        }
    }




    protected void btnFinish_Click(object sender, EventArgs e)
    {
        Response.Redirect("Finish.aspx");
    }

   

    
}
