﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;


public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = @"SELECT studentID, schoolName FROM students
                            WHERE studentIDNumber=@studentIDNumber AND studentPW=@studentPW";

            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                cmd.Parameters.AddWithValue("@studentIDNumber", txtIDNumber.Text);
                cmd.Parameters.AddWithValue("@studentPW", txtPassword.Text);

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    if (dr.HasRows)
                    {
                        if (dr.Read())
                        {
                            Session["SchoolName"] = dr["schoolName"].ToString();
                            Session["studentID"] = dr["studentID"].ToString();
                        }
                        Response.Redirect("Home.aspx");
                    }
                    else
                    {
                        error.Visible = true; // email and password doesn't match </3
                    }
                }
                }
            }
        }
    }