﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class SHRIM : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetSHRIM();
            GetSHRIM2();
            GetSHRIM3();
            GetSHRIM4();
            GetSHRIM5();

            GetCSG();
            GetCSG2();
            GetCSG3();
            GetCSG4();
            GetCSG5();
        }
    }

    void GetSHRIM()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=11";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlSHRIM.DataSource = data;
                    ddlSHRIM.DataTextField = "canName";
                    ddlSHRIM.DataValueField = "canID";
                    ddlSHRIM.DataBind();

                    ddlSHRIM.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }

    void GetSHRIM2()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=12";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlSHRIM2.DataSource = data;
                    ddlSHRIM2.DataTextField = "canName";
                    ddlSHRIM2.DataValueField = "canID";
                    ddlSHRIM2.DataBind();

                    ddlSHRIM2.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }

    void GetSHRIM3()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=13";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlSHRIM3.DataSource = data;
                    ddlSHRIM3.DataTextField = "canName";
                    ddlSHRIM3.DataValueField = "canID";
                    ddlSHRIM3.DataBind();

                    ddlSHRIM3.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }


    void GetSHRIM4()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=14";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlSHRIM4.DataSource = data;
                    ddlSHRIM4.DataTextField = "canName";
                    ddlSHRIM4.DataValueField = "canID";
                    ddlSHRIM4.DataBind();

                    ddlSHRIM4.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }


    void GetSHRIM5()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=15";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlSHRIM5.DataSource = data;
                    ddlSHRIM5.DataTextField = "canName";
                    ddlSHRIM5.DataValueField = "canID";
                    ddlSHRIM5.DataBind();

                    ddlSHRIM5.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }


    protected void ddlSHRIM_SelectedIndexChanged(object sender, EventArgs e)
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = @"INSERT INTO votes VALUES(@canID, @studentID, @DateAdded)";

            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                cmd.Parameters.AddWithValue("@canID", ddlSHRIM.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@studentID", ddlSHRIM.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@DateAdded", DateTime.Now);
                cmd.ExecuteNonQuery();
            }
        }
    }


    void GetCSG()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=1";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlCSG.DataSource = data;
                    ddlCSG.DataTextField = "canName";
                    ddlCSG.DataValueField = "canID";
                    ddlCSG.DataBind();

                    ddlCSG.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }

    void GetCSG2()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=2";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlCSG2.DataSource = data;
                    ddlCSG2.DataTextField = "canName";
                    ddlCSG2.DataValueField = "canID";
                    ddlCSG2.DataBind();

                    ddlCSG2.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }

    void GetCSG3()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=3";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlCSG3.DataSource = data;
                    ddlCSG3.DataTextField = "canName";
                    ddlCSG3.DataValueField = "canID";
                    ddlCSG3.DataBind();

                    ddlCSG3.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }

    void GetCSG4()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=4";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlCSG4.DataSource = data;
                    ddlCSG4.DataTextField = "canName";
                    ddlCSG4.DataValueField = "canID";
                    ddlCSG4.DataBind();

                    ddlCSG4.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }
    void GetCSG5()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = "SELECT canID, canName, positionID FROM candidates WHERE positionID=5";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {

                using (SqlDataReader data = cmd.ExecuteReader())
                {
                    ddlCSG5.DataSource = data;
                    ddlCSG5.DataTextField = "canName";
                    ddlCSG5.DataValueField = "canID";
                    ddlCSG5.DataBind();

                    ddlCSG5.Items.Insert(0, new ListItem("Select a candidate...", ""));
                }
            }
        }
    }

    protected void ddlCSG_SelectedIndexChanged(object sender, EventArgs e)
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {

            con.Open();
            string SQL = @"INSERT INTO votes VALUES(@canID, @studentID, @DateAdded)";

            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                cmd.Parameters.AddWithValue("@canID", ddlCSG.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@studentID", ddlCSG.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@DateAdded", DateTime.Now);
                cmd.ExecuteNonQuery();
            }
        }
    }




    protected void btnFinish_Click(object sender, EventArgs e)
    {
        Response.Redirect("Finish.aspx");
    }
    
}
