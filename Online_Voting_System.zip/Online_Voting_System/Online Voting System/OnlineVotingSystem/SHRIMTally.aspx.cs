﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class SHRIMTally : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetVotes_SHRIM_PRESIDENT();
            GetVotes_SHRIM_SECRETARY();
            GetVotes_SHRIM_PUBLIC();
            GetVotes_SHRIM_114();
            GetVotes_SHRIM_115();
        }
    }


    void GetVotes_SHRIM_PRESIDENT()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = @"SELECT c.canName,
                (SELECT COUNT(VoteID) FROM votes v
                WHERE v.canID = c.canID) AS TotalVotes
                 FROM candidates c
                WHERE c.positionID = 11";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    lvResults_SHRIM_PRESIDENT.DataSource = dr;
                    lvResults_SHRIM_PRESIDENT.DataBind();
                }
            }
        }
    }

    void GetVotes_SHRIM_SECRETARY()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = @"SELECT c.canName,
                (SELECT COUNT(VoteID) FROM votes v
                WHERE v.canID = c.canID) AS TotalVotes
                 FROM candidates c
                WHERE c.positionID = 12";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    lvResults_SHRIM_SECRETARY.DataSource = dr;
                    lvResults_SHRIM_SECRETARY.DataBind();
                }
            }
        }
    }

    void GetVotes_SHRIM_PUBLIC()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = @"SELECT c.canName,
                (SELECT COUNT(VoteID) FROM votes v
                WHERE v.canID = c.canID) AS TotalVotes
                 FROM candidates c
                WHERE c.positionID = 13";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    lvResults_SHRIM_PUBLIC.DataSource = dr;
                    lvResults_SHRIM_PUBLIC.DataBind();
                }
            }
        }
    }

    void GetVotes_SHRIM_114()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = @"SELECT c.canName,
                (SELECT COUNT(VoteID) FROM votes v
                WHERE v.canID = c.canID) AS TotalVotes
                 FROM candidates c
                WHERE c.positionID = 14";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    lvResults_SHRIM_114.DataSource = dr;
                    lvResults_SHRIM_114.DataBind();
                }
            }
        }
    }

    void GetVotes_SHRIM_115()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = @"SELECT c.canName,
                (SELECT COUNT(VoteID) FROM votes v
                WHERE v.canID = c.canID) AS TotalVotes
                 FROM candidates c
                WHERE c.positionID = 15";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    lvResults_SHRIM_115.DataSource = dr;
                    lvResults_SHRIM_115.DataBind();
                }
            }
        }
    }
    protected void btnSchools_Click(object sender, EventArgs e)
    {
        Response.Redirect("Schools.aspx");
    }

}
