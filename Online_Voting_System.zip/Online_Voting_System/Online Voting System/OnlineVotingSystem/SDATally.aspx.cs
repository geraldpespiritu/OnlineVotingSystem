﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class SDATally : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetVotes_SDA_PRESIDENT();
            GetVotes_SDA_SECRETARY();
            GetVotes_SDA_PUBLIC();
            GetVotes_SDA_114();
            GetVotes_SDA_115();
        }
    }


    void GetVotes_SDA_PRESIDENT()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = @"SELECT c.canName,
                (SELECT COUNT(VoteID) FROM votes v
                WHERE v.canID = c.canID) AS TotalVotes
                 FROM candidates c
                WHERE c.positionID = 6";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    lvResults_SDA_PRESIDENT.DataSource = dr;
                    lvResults_SDA_PRESIDENT.DataBind();
                }
            }
        }
    }

    void GetVotes_SDA_SECRETARY()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = @"SELECT c.canName,
                (SELECT COUNT(VoteID) FROM votes v
                WHERE v.canID = c.canID) AS TotalVotes
                 FROM candidates c
                WHERE c.positionID = 7";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    lvResults_SDA_SECRETARY.DataSource = dr;
                    lvResults_SDA_SECRETARY.DataBind();
                }
            }
        }
    }

    void GetVotes_SDA_PUBLIC()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = @"SELECT c.canName,
                (SELECT COUNT(VoteID) FROM votes v
                WHERE v.canID = c.canID) AS TotalVotes
                 FROM candidates c
                WHERE c.positionID = 8";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    lvResults_SDA_PUBLIC.DataSource = dr;
                    lvResults_SDA_PUBLIC.DataBind();
                }
            }
        }
    }

    void GetVotes_SDA_114()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = @"SELECT c.canName,
                (SELECT COUNT(VoteID) FROM votes v
                WHERE v.canID = c.canID) AS TotalVotes
                 FROM candidates c
                WHERE c.positionID = 9";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    lvResults_SDA_114.DataSource = dr;
                    lvResults_SDA_114.DataBind();
                }
            }
        }
    }

    void GetVotes_SDA_115()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = @"SELECT c.canName,
                (SELECT COUNT(VoteID) FROM votes v
                WHERE v.canID = c.canID) AS TotalVotes
                 FROM candidates c
                WHERE c.positionID = 10";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    lvResults_SDA_115.DataSource = dr;
                    lvResults_SDA_115.DataBind();
                }
            }
        }
    }

    protected void btnSchools_Click(object sender, EventArgs e)
    {
        Response.Redirect("Schools.aspx");
    }

}
