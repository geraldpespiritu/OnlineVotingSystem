﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class CSGTally : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetVotes_CSG_PRESIDENT();
            GetVotes_CSG_ACADEMICS();
            GetVotes_CSG_FINANCE();
            GetVotes_CSG_INTERNAL();
            GetVotes_CSG_OPERATIONS();

        }
    }


    void GetVotes_CSG_PRESIDENT()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = @"SELECT c.canName,
                (SELECT COUNT(VoteID) FROM votes v
                WHERE v.canID = c.canID) AS TotalVotes
                 FROM candidates c
                WHERE c.positionID = 1";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    lvResults_CSG_PRESIDENT.DataSource = dr;
                    lvResults_CSG_PRESIDENT.DataBind();
                }
            }
        }
    }

    void GetVotes_CSG_ACADEMICS()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = @"SELECT c.canName,
                (SELECT COUNT(VoteID) FROM votes v
                WHERE v.canID = c.canID) AS TotalVotes
                 FROM candidates c
                WHERE c.positionID = 2";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    lvResults_CSG_ACADEMICS.DataSource = dr;
                    lvResults_CSG_ACADEMICS.DataBind();
                }
            }
        }
    }

    void GetVotes_CSG_FINANCE()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = @"SELECT c.canName,
                (SELECT COUNT(VoteID) FROM votes v
                WHERE v.canID = c.canID) AS TotalVotes
                 FROM candidates c
                WHERE c.positionID = 3";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    lvResults_CSG_FINANCE.DataSource = dr;
                    lvResults_CSG_FINANCE.DataBind();
                }
            }
        }
    }
    void GetVotes_CSG_INTERNAL()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = @"SELECT c.canName,
                (SELECT COUNT(VoteID) FROM votes v
                WHERE v.canID = c.canID) AS TotalVotes
                 FROM candidates c
                WHERE c.positionID = 4";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    lvResults_CSG_INTERNAL.DataSource = dr;
                    lvResults_CSG_INTERNAL.DataBind();
                }
            }
        }
    }
    void GetVotes_CSG_OPERATIONS()
    {
        using (SqlConnection con = new SqlConnection(Helper.GetConnection()))
        {
            con.Open();
            string SQL = @"SELECT c.canName,
                (SELECT COUNT(VoteID) FROM votes v
                WHERE v.canID = c.canID) AS TotalVotes
                 FROM candidates c
                WHERE c.positionID = 5";
            using (SqlCommand cmd = new SqlCommand(SQL, con))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    lvResults_CSG_OPERATIONS.DataSource = dr;
                    lvResults_CSG_OPERATIONS.DataBind();
                }
            }
        }
    }

    protected void btnSchools_Click(object sender, EventArgs e)
    {
        Response.Redirect("Schools.aspx");
    }

}
